import axios from 'axios'
import React from 'react'

function Like({selfData}) {
    
  return (
    <div>
        <i class="fa fa-heart-o text-[25px]" aria-hidden="true"></i>
    </div>
  )
}

export default Like